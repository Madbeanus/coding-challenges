// AND Digital Coding Challenge
// Cadidate: Samuel Cooper
// Session 1 start time 9:51am end time 11:34am on 05/03/19
// Session 2 start time 4:30pm end time 6:31pm on 05/03/19
// Session 3 start time 8:00pm end time 8:39pm on 05/03/19

Hello I'm Samuel Cooper. This is just a rundown of what all these files I've produced are all about.
- I first thought up some logic for the filtering function which basically involved doing some research
on JavaScript as I'd never used it before and discovering the .includes function for Arrays. The rest was
simple logic and looping.
- Afterwards I felt my improvements lied in creating classes to represent the candidates, containing functions
which would be able to conveniently display data in various ways, such as in a table. Before writing any
code I drew up some UML diagrams you can see in uml.jpg. Just the basics so you have an idea of my knowledge and
understanding.
- Then I began writing the code in a separate scripts.js file. After this was complete I
tested it away from index.html in a test.html file which was basically the bare functionality.
- When I understood some of the possible issues and how it should actually work I wrote some unit tests using Jasmine in scriptsTest.js
which you can run by opening IndexTest.html. This assured I had everything working properly.
- Finally I implemeneted a couple of new tables in index.html to complete the task. Filtering by JavaScript and then
AWS.
